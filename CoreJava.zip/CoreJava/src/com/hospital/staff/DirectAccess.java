package com.hospital.staff;

public class DirectAccess extends com.hospital.staff.doctor.salary.Salary {
	public static void main(String[] args) {
		

		DirectAccess ob = new DirectAccess();

		System.out.println(ob.calculatesalary(15000, 500));

			

		
	}
}
