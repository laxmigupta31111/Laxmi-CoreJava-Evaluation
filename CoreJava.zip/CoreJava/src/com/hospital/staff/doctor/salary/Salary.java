package com.hospital.staff.doctor.salary;

public class Salary {
	
	public static void main(String[] args) {
		protected double calculatesalary(double amt, double tax) 
		{

			return amt + tax;

		}
	}

}
