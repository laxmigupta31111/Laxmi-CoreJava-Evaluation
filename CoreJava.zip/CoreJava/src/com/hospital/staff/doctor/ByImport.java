package com.hospital.staff.doctor;

import com.hospital.staff.doctor.salary.Salary;

public class ByImport {

		public static void main(String[] args) {

		ByImport ob = new ByImport();

		System.out.println(ob.calculatesalary(10000, 150));

		
	}
}
