
//10. Write the pojo for following attributes?
//a. Name
//b. salary
//c. id


package q10;

public class POJO {

	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	private double salary;
	private int id ;
}
