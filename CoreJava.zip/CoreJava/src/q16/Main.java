// 16. Show an example of super keyword?

	package q16;

	class A {
	    String name = "A";

	    A() {
	        System.out.println("A Constructor");
	    }

	    void show() {
	        System.out.println("A Method");
	    }
	}

	class B extends A {
	    B() {
	        super();
	    }

	    void display() {
	        System.out.println(super.name);
	        super.show();                 
	    }
	}

	public class Main {
	    public static void main(String[] args) {
	        B obj = new B();
	        obj.display();
	    }
	}
 

