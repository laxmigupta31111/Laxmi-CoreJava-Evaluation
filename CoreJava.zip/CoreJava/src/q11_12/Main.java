
//11. Show an example of method overloading?
//12. Show an example of method overriding? 


package q11_12;


class Emp{

	void calSal(double sal) {

	System.out.println(sal);

	}

	void calSal(double sal, double bouns) {

	System.out.println(sal+bouns);

	}

}

class Staff extends Emp{

	@Override

	void calSal(double sal) {

		super.calSal(sal);

	}

}

public class Main {



	public static void main(String[] args) {

	Staff staff = new Staff();

	staff.calSal(1000);

	

	Emp emp= new Emp();

	emp.calSal(10000);

	emp.calSal(15000, 500);

	}

}