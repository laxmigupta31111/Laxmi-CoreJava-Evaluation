package q23;

public class Main {

}
