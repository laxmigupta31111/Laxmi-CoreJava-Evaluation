package q2;

// 3. Show an example of dynamic method dispatch?

public class Main {

}
