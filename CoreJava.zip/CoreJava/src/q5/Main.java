package q5;

// 5. Show an example of object cloning? Override hashcode and equal contract?

class Emp implements Cloneable {
    String name;
    int    id;

    public Emp(String name, int id) {
        this.name = name;
        this.id   = id;
    }


    @Override
    public Emp clone() throws CloneNotSupportedException {
        return (Emp) super.clone();
    }

  
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Emp)) return false;
        Emp other = (Emp) obj;
        return id == other.id && name.equals(other.name);
    }

    
    @Override
    public int hashCode() {
        return 31 * id + name.hashCode();
    }

    @Override
    public String toString() {
        return "Emp [name=" + name + ", id=" + id + "]";
    }
}

public class Main {
    public static void main(String[] args) throws CloneNotSupportedException {
        Emp emp1 = new Emp("Tom", 07);
        Emp emp2 = emp1.clone();

        System.out.println("Original : " + emp1);
        System.out.println("Clone    : " + emp2);
        System.out.println("equals() : " + emp1.equals(emp2));   
        System.out.println("hashCode : " + (emp1.hashCode() == emp2.hashCode())); 
        System.out.println("== (ref) : " + (emp1 == emp2));     
    }
}
