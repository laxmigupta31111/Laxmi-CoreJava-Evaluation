package q28;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

	public class Authentication_Authorization extends JFrame{

		JLabel l1,l2;
		JTextField t1,t2;
		JButton btn1,btn2;

		public void Login() {
		setLayout(new FlowLayout());	
		
		setSize(400,400);
		setVisible(true);
		
		l1=new JLabel("Username");
		t1=new JTextField(20);
		l2=new JLabel("Password");
		t2=new JTextField(20);
		btn1=new JButton("Submit");
		btn1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
					if (t1.getText().equals("admin") && t2.getText().equals("admin")) {
						System.out.println("Login");
							
					} else {
						System.out.println("Login Failed");

					}
			
			}
		});
		
		btn2=new JButton("Reset");
		btn2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				t1.setText("");
				t2.setText("");
			}
		});
		
		add(l1);
		add(t1);
		add(l2);
		add(t2);
		add(btn1);
		add(btn2);
		setSize(400,400);
		setVisible(true);
		}
		public static void main(String[] args) {
			
			new Authentication_Authorization();
		}
		
		
	}





