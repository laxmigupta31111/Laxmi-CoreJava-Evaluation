package q22;

public class Thread {

}
