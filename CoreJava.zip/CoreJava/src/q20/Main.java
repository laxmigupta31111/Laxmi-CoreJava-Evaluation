
//20. Create class emp with its important attributes 
//like name/id/sal/address. Display all the info
//display all the info with tostring




package q20;

class Emp{
	String name = "tom";
	int id= 7;
	double sal = 25000;
	String add = "mumbai";
	
	@Override
	public String toString() {
		return "Emp [name=" + name + ", id=" + id + ", sal=" + sal + ", add=" + add + "]";
	}


	
	
	public void DisplayInfo() {
		System.out.println(name);
		System.out.println(id);
		System.out.println(sal);
		System.out.println(add);
	}
	
}


public class Main {

	public static void main(String[] args) {
		Emp ob = new Emp();
		ob.DisplayInfo();
	}
}
