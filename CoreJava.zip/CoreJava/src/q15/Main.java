
// 15. Show an example of parameterized constructor.

package q15;

public class Main {
	
	String name ;
	int id ;
	double sal;
	
	
	@Override
	public String toString() {
		return "Main [name=" + name + ", id=" + id + ", sal=" + sal + "]";
	}
	
	public Main(String name, int id, double sal) {
		super();
		this.name = name;
		this.id = id;
		this.sal = sal;
	}
	
	public static void main(String[] args) {
		Main ob = new Main("Tom", 7, 25000);
		System.out.println(ob);
	}
}
