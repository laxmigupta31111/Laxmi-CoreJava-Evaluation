git cpackage q3;

public class Main {

	class Bank {
		return 0;
	}
	class SBI extends Bank {
		return 5.9;
	}
	
	
	public static void main(String[] args) {
		Bank a;
		a = new SBI();
		System.out.println(a);
	}
}
