package q18;

// d. list iterator

import java.util.*;
import java.util.ListIterator;

public class Main4{
	
	public static void main(String[] args) {
		
		List<String> names = new LinkedList<>();
		names.add(" ");
		names.add("Tom");
		names.add("Jerry");
		names.add("Harry");
		
		ListIterator<String> namesIterator = names.listIterator();
		
		 // Forward
		while(namesIterator.hasNext())
		{
			System.out.println(namesIterator.next());
		}
		
		
		
		while(namesIterator.hasPrevious())
		{
			System.out.println(namesIterator.previous());
		}
		
		
		
		for(String name: names)
		{
			System.out.println(name);
		}
	
	}
}

