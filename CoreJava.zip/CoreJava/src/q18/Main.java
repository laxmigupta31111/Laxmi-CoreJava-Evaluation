package q18;

//18. Show an example of object iteration by using following components
//a. For each loop
//b. iterator
//c. enumerator
//d. list iterator



import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		
		 ArrayList<String> list = new ArrayList<>();
	        list.add("Tom");
	        list.add("Jerry");
	        list.add("Henry");

	        
	        for(String lang : list) {
	            System.out.println(lang);
	            
	         
	            
	        }
	}
}












