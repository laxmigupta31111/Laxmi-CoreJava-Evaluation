package q18;

// b. iterator

import java.util.ArrayList;
import java.util.Iterator;

public class Main2 {
	 public static void main(String[] args) {

	        ArrayList<String> list = new ArrayList<>();
	        list.add("A");
	        list.add("B");
	        list.add("C");

	        Iterator<String> it = list.iterator();

	        while(it.hasNext()) {
	            String value = it.next();
	            System.out.println(value);
	        }
	    }

}

