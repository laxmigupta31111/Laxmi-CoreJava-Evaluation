package q14_2;

import q14.Main;

public class Main3 extends Main {

	public static void main(String[] args) {
		Main3 ob = new Main3();
		System.out.println(ob.pro);
		System.out.println(ob.pub);
	}
}
