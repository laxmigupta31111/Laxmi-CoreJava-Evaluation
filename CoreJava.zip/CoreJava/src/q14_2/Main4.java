package q14_2;
import q14;


public class Main4 {
	public static void main(String[] args) {
        Main4 m = new Main4();
        System.out.println(m.pub);
       
    }
}
