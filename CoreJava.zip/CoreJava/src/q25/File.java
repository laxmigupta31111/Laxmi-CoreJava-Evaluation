package q25;

public class File {

}
