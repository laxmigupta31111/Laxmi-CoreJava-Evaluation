package q14;

public class Main2 extends Main{
	public static void main(String[] args) {
		
		Main2 ob = new Main2();
		System.out.println(ob.def);
		System.out.println(ob.pro);
		System.out.println(ob.pub);
	}
}
