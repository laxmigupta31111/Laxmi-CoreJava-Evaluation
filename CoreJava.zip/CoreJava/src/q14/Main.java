
package q14;
public class Main {

    public    String pub  = "public";
    protected String pro  = "protected";
              String def  = "default";
    private   String priv = "private";

    public static void main(String[] args) {
    	
        Main m = new Main();
     
        System.out.println(m.pub);
        System.out.println(m.pro);
        System.out.println(m.def);
        System.out.println(m.priv);
       
    }
	

	
}
