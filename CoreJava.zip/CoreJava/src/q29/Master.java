package q29;



import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;

public class Master {

	JMenu menu , submenu;
	JMenuItem about , service , location , exit, d1,d2,d3, p1, p2_1 , p2_2 , p2_3 , p3   ,a1  ;
	
	Master(){
		JFrame frame = new JFrame("Master Page ");
		JMenuBar mb = new JMenuBar();
		
		//home
		menu = new JMenu("HOME");
		about = new JMenuItem("About Us");
		service = new JMenuItem("Service");
		exit = new JMenuItem("Exit");
		
		menu.add(about);
		menu.add(service);
		menu.add(exit);

		mb.add(menu);
		frame.setJMenuBar(mb);
		
		// Doctor
		menu = new JMenu("DOCTOR");
		d1 = new JMenuItem("Dr.Info");
		d2 = new JMenuItem("Dr.Registration");
		
		
		menu.add(d1);
		menu.add(d2);
		
		
		mb.add(menu);
		frame.setJMenuBar(mb);
		
		//patient
		menu = new JMenu("PATIENT");
		submenu = new JMenu("Billing");
		p1 = new JMenuItem("Patient details");
		p2_1 = new JMenuItem("With GST");
		p2_2 = new JMenuItem("NGO Accounts");
		p2_3 = new JMenuItem("Payment Details");
		p3 = new JMenuItem("Exit");
		
		menu.add(p1);
		submenu.add(p2_1);
		submenu.add(p2_2);
		submenu.add(p2_3);
		menu.add(p3);
		
		menu.add(submenu);
		mb.add(menu);
		frame.setJMenuBar(mb);
		
		
		
	
		
	
		
		frame.setSize(400, 400);
		frame.setLayout(null);
		frame.setVisible(true);
	
	}
	
	public static void main(String[] args) {
		new Master();
	}
}





